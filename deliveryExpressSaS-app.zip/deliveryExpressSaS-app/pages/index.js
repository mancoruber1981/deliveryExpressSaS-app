import { useState } from "react";

export default function Home() {
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [rate, setRate] = useState(16000);
  const [total, setTotal] = useState(null);
  const [summary, setSummary] = useState("");

  function calculateTotal() {
    const start = new Date(`2000-01-01T${startTime}`);
    const end = new Date(`2000-01-01T${endTime}`);
    const diffMs = end - start;
    if (diffMs <= 0) return alert("La hora final debe ser mayor que la inicial.");

    const diffHrs = diffMs / 1000 / 60 / 60;
    const fullHours = Math.floor(diffHrs);
    const minutes = Math.round((diffHrs - fullHours) * 60);
    const pay = Math.round(diffHrs * rate);

    setTotal(pay);
    setSummary(
      `Servicio desde las ${startTime} hasta las ${endTime} (${fullHours}h ${minutes}min), valor hora $${rate.toLocaleString()}, total a pagar $${pay.toLocaleString()}`
    );
  }

  return (
    <main style={{ maxWidth: 600, margin: "auto", padding: 20 }}>
      <h1>Mensajería Delivery Express SAS</h1>
      <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
      <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
      <input type="number" value={rate} onChange={(e) => setRate(Number(e.target.value))} placeholder="Valor por hora" />
      <button onClick={calculateTotal}>Calcular</button>
      {summary && (
        <div style={{ marginTop: 20, background: "#e6ffe6", padding: 10, borderRadius: 8 }}>
          <p>{summary}</p>
        </div>
      )}
    </main>
  );
}